<?php
//this is module view
defined('_UOVCA') or die();

Template::loadJs(Page::myUrlDir().'/clock.js');
?>

<div id="bigtime">
	<!-- place for clock -->
</div>


