<?php
defined('_UOVCA') or die();

echo '<h2>fooooter</h2>';