<?php
//this is module view
defined('_UOVCA') or die();

Template::setTitle('Panel')
?>

PANEL

